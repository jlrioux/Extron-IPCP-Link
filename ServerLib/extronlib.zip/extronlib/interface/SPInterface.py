class SPInterface():
    """ This class will provide a common interface for controlling and collecting data from AV components on Extron devices (extronlib.device) and Extron Secure Platform devices (SPDevice).

    Note:
        -

    ---

    Arguments:
        - Host (extronlib.device) - handle to Extron device class that instantiated this interface class

    ---

    Parameters:
        - Host - Returns (extronlib.device) - the host device

    ---

    Events:
        - Offline - (Event) Triggers when port goes offline. The callback takes two arguments. The first one is the extronlib.interface.SPInterface instance triggering the event and the second one is a string ('Offline').
        - Online - (Event) Triggers when port goes online. The callback takes two arguments. The first one is the extronlib.interface.SPInterface instance triggering the event and the second one is a string ('Online').
        - ReceiveData - (Event) Receive Data event handler used for asynchronous transactions. The callback takes two arguments. The first one is the SPInterface instance triggering the event and the second one is a bytes string.
    """

    def __init__(self, Host):
        """ SPInterface class constructor.

        Arguments:
            - Host (extronlib.device) - handle to Extron device class that instantiated this interface class
        """
        self.Host = Host
        self.ReceiveData = None

    def Send(self, data):
        """ Send string over serial port if it’s open

        Arguments:
            - data (bytes, string) - data to send

        Raises:
            - TypeError
            - IOError
        """
        pass
