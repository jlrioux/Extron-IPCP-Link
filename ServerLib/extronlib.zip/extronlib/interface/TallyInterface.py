class TallyInterface():
    """ This class provides an interface to a tally interface.

    Note:
        - State value will be either 'On' or 'Off'

    ---

    Arguments:
        - Host (extronlib.device) - handle to Extron device class that instantiated this interface class
        - Port (string) - port name (e.g.  'TAL1')

    ---

    Parameters:
        - Host - Returns (extronlib.device) - the host device
        - Port - Returns (string) - the port name this interface is attached to

    ---

    Events:
        - Offline - (Event) Triggers when port goes offline. The callback takes two arguments. The first one is the extronlib.interface instance triggering the event and the second one is a string ('Offline').
        - Online - (Event) Triggers when port goes offline. The callback takes two arguments. The first one is the extronlib.interface instance triggering the event and the second one is a string ('Online').
        - ReceiveData - (Event) Receive Data event handler used for asynchronous transactions. The callback takes two arguments. The first one is the SerialInterface instance triggering the event and the second one is a bytes string.
    """

    def __init__(self, Host, Port):
        """ TallyInterface class constructor.

        Arguments:
            - Host (extronlib.device) - handle to Extron device class that instantiated this interface class
            - Port (string) - port name (e.g.  'TAL1')
        """
        self.Host = Host
        self.Port = Port
        State = ''
        Offline = False
        Online = True

    def SetState(self, State):
        """ Send string over serial port if it’s open

        Arguments:
            - State (int, string) - output state to be set ('On' or 1, 'Off' or 0)
        """
        pass

    def Toggle(self):
        """ Changes the state of the Tally port to the logical opposite of the current state.
        """
        pass
