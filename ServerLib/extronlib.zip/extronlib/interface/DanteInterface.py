class DanteInterface():
    """ This class will provide a common interface for controlling and collecting data from Dante Input ports on Extron devices (extronlib.device). The user can instantiate the class directly or create a subclass to add, remove, or alter behavior for different types of devices.

    Parameters:
        - DeviceName (string) - Device name of the Dante controlled device.
        - Protocol (string) - Protocol type used. ('Extron' is the only supported protocol at this time)
        - DanteDomainManager (DanteDomainManager) - Dante Domain Manager of the Dante controlled device.
        - Domain (string) - Dante domain this device is assigned to.

    ---

    Events:
        - Disconnected - (Event) Triggers when a connection is broken
        - Connected - (Event) Connected
        - ReceiveData - (Event) Receive Data event handler used for asynchronous transactions
    """

    def StartService(lan='LAN'):
        pass
    def __init__(self, DeviceName: str, Protocol='Extron',DanteDomainManager=None,Domain=None):
        """ DanteInterface class constructor.

        Arguments:
            - Host (extronlib.device) - handle to Extron device class that instantiated this interface class
            - Port (string) - port name (e.g. 'CII1')
        """
        self.DeviceName = DeviceName
        """ Device name of the Dante controlled device."""
        self.Protocol = Protocol
        """Protocol type used. (‘Extron’ is the only supported protocol at this time)"""
        self.DanteDomainManager = DanteDomainManager
        """Dante Domain Manager of the Dante controlled device."""
        self.Domain = Domain
        """Dante domain this device is assigned to."""

        """
        from extronlib import event, Version
        from extronlib.interface import DanteInterface

        print(Version())

        # Always required once per project
        DanteInterface.StartService('AVLAN')

        axi22at = DanteInterface('AXI22-AB-CD-EF')

        def ConnectAXI22at():
            result = axi22at.Connect(5)
            if 'Connected' not in result:
                Wait(30, ConnectAXI22at)
            else:
                GetStatus(axi22at)    # GetStatus() is a user function

        ConnectAXI22at()

        @event(axi22at, ['Connected', 'Disconnected'])
        def handleConnection(interface, state):
            print(interface.Hostname, state)

        @event(axi22at, 'ReceiveData')
        def handleRecvData(interface, data):
            print(interface.Hostname, data)
                ```
                @event(SomeInterface, ['Online', 'Offline'])
                def HandleConnection(interface, state):
                    print('{} is now {}'.format(interface.Port, state))
                ```
        """
        self.Connected = ''
        """
        Event:
            -Triggers when a connection is established.
            -The callback takes two arguments. The first one is the DanteInterface instance triggering the event and the second one is a string ('Connected').
        """
        self.Disconnected = ''
        """	Event:
                - Triggers when a connection is broken
                - The callback takes two arguments. The first one is the DanteInterface instance triggering the event and the second one is a string ('Disconnected').
        """
        self.ReceiveData = None

        """
        Event:
            - Receive Data event handler used for asynchronous transactions
            - The callback takes two arguments. The first one is the DanteInterface instance triggering the event and the second one is a bytes object.
            - Dante controlled devices always provide verbose, tagged responses.
            - The maximum amount of data per ReceiveData event that will be passed into the handler is 1024 bytes. For payloads greater than 1024 bytes, multiple events will be triggered.
        ```
        @event(axi22at, 'ReceiveData')
        def handleRecvData(interface, data):
            print(interface.Hostname, data)
        ```
        """
    def Connect(self,timeout=None):
        pass
    """
    Connect to the device

    Parameters:	timeout (float) – time in seconds to attempt connection before giving up.
    Returns:	'Connected' or 'ConnectedAlready' or reason for failure
    Return type:	string
    """
    def Disconnect(self):
        pass
    """
    Disconnect the session
    """

    def Send(self,data):
        pass
    """
    Start the Dante Service.

    Parameters:	interface (string) – Defines the network interface connected to the Dante network ('LAN', or 'AVLAN')
    Returns:	'ServiceStarted' or a reason for failure
    The possible return values are:

    'ServiceStarted'
    'ServiceStartedAlready'
    'PortUnavailable'
    'InterfaceUnavailable: LAN'
    'InterfaceUnavailable: AVLAN'
    """
