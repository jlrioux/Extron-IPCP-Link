
class SPDevice():
    """ Defines common interface to Extron Control Secure Platform Devices

    Note:
        - `DeviceAlias` must be a valid device Device Alias of an Extron device in the system.
        - If the part number is provided, the device will trigger a warning message in the program log if it does not match the connected device.

    ---

    Functions:
        - Reboot: Performs a soft restart of this device – this is equivalent to rebooting a PC.

    ---

    Arguments:
        - DeviceAlias (string) - Device Alias of the Extron device
        - (optional) PartNumber  (string) - device’s part number

    ---

    Parameters:
        - CombinedCurrent - Returns (float) - instantaneous current draw across all switched AC power receptacles in Amperes
        - CombinedLoadState - Returns (str) - The current power limit state. One of 'Normal', 'Limit', or 'Over'.
        - CombinedWattage - Returns (float) - the current power usage across all DC power outputs in watts
        - DeviceAlias - Returns (string) - the device alias of the object
        - FirmwareVersion - Returns (string) - the firmware version of this device
        - Hostname - Returns (string) - the hostname of this device
        - IPAddress - Returns (string) - IP address of this device
        - LinkLicenses - Returns (list of strings) - List of LinkLicense® part numbers.
        - MACAddress - Returns (string) - MAC address of this device. For dual NIC devices, the LAN address is returned.
        - ModelName - Returns (string) - Model name of this device
        - PartNumber - Returns (string) - the part number of this device
        - SerialNumber - Returns (string) - Serial number of this device
        - SystemSettings - Returns (dict) - a dictionary of data describing the settings (defined in Toolbelt) of this device

    ---

    Events:
        - CombinedCurrentChanged - (Event) Get/Set the callback function called when the switched AC power receptacle current draw changes. The callback function must accept exactly two parameters, which are the SPDevice that triggers the event and the new current in Amperes as a float (e.g. 10.5).
        - Offline - (Event) Triggers when the device goes offline. The callback takes two arguments. The first one is the extronlib.device instance triggering the event and the second one is a string ('Offline').
        - Online - (Event) Triggers when the device comes online. The callback takes two arguments. The first one is the extronlib.device instance triggering the event and the second one is a string ('Online').

    ---

    Example:
    ```
    # Create Primary Processor
    ConfRoom = ProcessorDevice('Main')

    # Create Secondary Processor, Confirm Partnumber
    ConfRoom3 = ProcessorDevice('profRobertsRm', '60-1234-01')

    # Create Touch Panel
    PodiumTLP = UIDevice('Podium TLP')

    # Create System Switcher AV Device
    SystemSwitcher = SPDevice('SysSwitcher')
    ```
    """


    def __init__(self, DeviceAlias: str, PartNumber: str=None):
        """
        ProcessorDevice class constructor.

        Arguments:
            - DeviceAlias (string) - Device Alias of the Extron device
            - PartNumber  (string) - device’s part number
        """

        self.CombinedCurrent = None
        """	Float : instantaneous current draw across all switched AC power receptacles in Amperes
        """
        self.DeviceAlias = ''
        self.CombinedCurrentChanged = None
        """ Event: Get/Set the callback function called when the switched AC power receptacle current draw changes.
            Note : This event triggers for each 0.1 Amp change but no more than once every 10 seconds if the current draw is oscillating.

        The callback function must accept exactly two parameters, which are the SPDevice that triggers the event and the new current in Amperes as a float (e.g. 10.5).
        ---

        Example:
        ```
        @event(spdevice, 'CombinedCurrentChanged')
        def HandleCombinedCurrent(device, current):
            print('Current draw changed to {}.'.format(current))
        ```
        """
        self.FirmwareVersion = ''
        self.HostName = ''
        self.IPAddress = ''
        """Note:
            - For control processors with AV LAN, the LAN address is returned."""
        self.LinkLicenses = []
        """	List of LinkLicense® part numbers."""
        self.MACAddress = ''
        """
        Note:
            - For control processors with AV LAN, the LAN address is returned.
        """
        self.ModelName = ''
        self.Offline = None
        """
        Event:
            -    Triggers when the device goes offline.

        The callback takes two arguments. The first one is the extronlib.device instance triggering the event and the second one is a string ('Offline').
        """
        self.Online = None
        """
        Event:
            -    Triggers when the device goes online.

        The callback takes two arguments. The first one is the extronlib.device instance triggering the event and the second one is a string ('Online').
        """
        self.PartNumber = ''
        self.SerialNumber = ''
        self.SystemSettings = {}
        """
        Returns:
            -    dict: a dictionary of data describing the settings (defined in Toolbelt) of this device

        ---

        Example:
        ```
        {
            'Network': {
                'LAN': {
                    'DNSServers': ['192.168.1.1',],
                    'Gateway': '192.168.254.1',
                    'Hostname': 'ConfRoom',
                    'IPAddress': '192.168.254.250',
                    'SubnetMask': '255.255.255.0',
                    'SearchDomains': ['extron.com',],
                },
            },
            'ProgramInformation': {
                'Author': 'jdoe',
                'DeviceName': 'TLP Pro 720T : 192.168.254.251',
                'FileLoaded': 'GS Project.gs',
                'LastUpdated': '1/23/2016 9:08:29 AM',
                'SoftwareVersion': '1.0.2.195',
            }
        }
        ```
        """

    def Reboot(self) -> None:
        """Performs a soft restart of this device – this is equivalent to rebooting a PC.

        ---

        ### WARNING
            -    Any unsaved data will be lost, including Program Log. Follow the example below.

        ---

        Example:
        ```
        from extronlib.system import File, SaveProgramLog
        from datetime import datetime

        # Save the ProgramLog for later inspection.
        dt = datetime.now()
        filename = 'ProgramLog {}.txt'.format(dt.strftime('%Y-%m-%d %H%M%S'))

        with File(filename, 'w') as f:
            -    SaveProgramLog(f)

        device.Reboot()
        ```
        """
        ...

    def SetExecutiveMode(self, ExecutiveMode: int) -> float:
        """ Sets the desired Executive Mode.

        ---

        Note:
            - See product manual for list of available modes.

        ---

        Arguments:
            - ExecutiveMode (int) - The mode to set. 0 to n.
        """
        ...
